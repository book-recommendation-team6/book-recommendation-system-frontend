import React from 'react';

function SectionHeader(props) {
    const {title, subtitle} = props;
    return (
         <div className="w-full mb-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-xl font-medium text-gray-800 dark:text-white mb-2">{title}</h1>
                    <div className="w-32 h-1 bg-red-500 rounded-t-2xl"></div>
                </div>
                {subtitle && (
                    <a href="#" className="text-gray-600 dark:text-gray-400 text-sm hover:underline">
                        Xem tất cả
                    </a>
                )}
            </div>
            <hr className="text-gray-200"/>
        </div>
    );
}

export default SectionHeader;