 const categories = {
  columns: [
    {
      title: "",
      items: [
        { id: 1, name: 'Lãnh đạo' },
        { id: 2, name: 'Tâm lý' },
        { id: 3, name: 'Kỹ năng' },
        { id: 4, name: 'Hạnh phúc' },
        { id: 5, name: 'Tâm linh' }
      ]
    },
    {
      title: "",
      items: [
        { id: 6, name: 'Lửa đời' },
        { id: 7, name: 'Công nghệ' },
        { id: 8, name: 'Kinh doanh' },
        { id: 9, name: 'Marketing' },
        { id: 10, name: 'Lịch sử' }
      ]
    },
    {
      title: "",
      items: [
        { id: 11, name: 'Sức khỏe' },
        { id: 12, name: 'Danh nhân' },
        { id: 13, name: 'Văn học' },
        { id: 14, name: 'Kinh tế' }
      ]
    }
  ]
};

export default categories;
