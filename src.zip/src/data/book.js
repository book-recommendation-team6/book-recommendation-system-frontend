const books = [
  {
    id: 1,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 2,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 22,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 23,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 24,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 3,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 4,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'recommended'
  },
  {
    id: 5,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 6,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 7,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 8,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 9,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 10,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 11,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 12,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 13,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 14,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 15,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'newest'
  },
  {
    id: 16,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 17,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 18,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 19,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 20,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  },
  {
    id: 21,
    title: 'Tết ở Làng Địa Ngục',
    author: 'Thảo Trang',
    cover: 'https://tiemsach.org/wp-content/uploads/2023/09/Tet-o-lang-dia-nguc.jpg',
    category: 'skills'
  }
];

export default books;
